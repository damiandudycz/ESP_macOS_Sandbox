/*
 * This file was automatically generated and should not be edited manually.
 */

#include <stdio.h>
#include <stdlib.h>
#include <libgen.h>
#include <string.h>

int main(int argc, const char * argv[]) {
    
    char *src_root = getenv("SRCROOT");
    char *project_name = getenv("PROJECT_NAME");
    char *script_name = getenv("SCRIPT_NAME");
    char *action = getenv("ACTION");
    
    char *cmdRun = malloc(
        strlen(src_root) + strlen("/") + strlen(script_name) + strlen(" ") + strlen(action) + strlen(" ") + strlen(project_name)
    );
    sprintf(cmdRun, "%s/%s %s %s", src_root, script_name, action, project_name);
    system(cmdRun);

    free(cmdRun);

    return 0;
    
}
