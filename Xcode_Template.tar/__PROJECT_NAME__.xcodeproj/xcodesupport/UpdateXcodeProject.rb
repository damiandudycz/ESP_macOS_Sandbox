require 'xcodeproj'

def scan(group, target, root)
  work_dir = "#{root}#{group.path}"
  files = Dir.glob(File.join(work_dir, '*'))

  files.each do |filename|
    basename = File.basename(filename)

    if File.directory?(filename)
      existing_group = group.children.find { |child| child.display_name == basename }
      if existing_group.nil?
        new_group = group.new_group(basename, basename)
      else
        new_group = existing_group
      end
      
      scan(new_group, target, "#{work_dir}/")
    else
      existing_file = group.files.find { |file| file.display_name == basename }
      if existing_file.nil?
        file = group.new_file(basename)
        target.add_file_references([file])
      end
    end
  end
end

project_path = ARGV[0]
project_name = ARGV[1]
project = Xcodeproj::Project.open(project_path)
target = project.targets.find { |target| target.name == project_name }
group = project.groups.first

scan(group, target, "")

project.save

