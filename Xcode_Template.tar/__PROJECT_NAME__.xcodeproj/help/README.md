# ESP-IDF Project manager for macOS

This tool allows creating and managing ESP-IDF project on macOS.
It includes functions for setting up environment tools in local directory,
create new project and create Xcode project.
